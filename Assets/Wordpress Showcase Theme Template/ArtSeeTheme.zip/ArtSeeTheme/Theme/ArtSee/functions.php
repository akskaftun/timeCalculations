<?php 

function the_title2($before = '', $after = '', $echo = true, $length = false) {
         $title = get_the_title();

      if ( $length && is_numeric($length) ) {

             $title = substr( $title, 0, $length );

          }

        if ( strlen($title)> 0 ) {

             $title = apply_filters('the_title2', $before . $title . $after, $before, $after);

             if ( $echo )

                echo $title;

             else

                return $title;

          }

      }

?>
<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
        'before_widget' => '<div class="sidebar-box">',
    'after_widget' => '</div>',
 'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));

?>
<?php
$themename = "Artsee Theme";
$shortname = "artsee";
$options = array (
    
    array(    "name" => "Body background color",
            "id" => $shortname."_body_backgroundcolor",
            "std" => "#E7E7DC",
            "type" => "text"),
    
    array(    "name" => "Wrapper Border Color",
            "id" => $shortname."_border_color",
            "std" => "#E3E3D5",
            "type" => "text"),
			
    array(    "name" => "Content Border Color",
            "id" => $shortname."_content_border",
            "std" => "#EDEDED",
            "type" => "text"),
			
	array(    "name" => "Link Color",
            "id" => $shortname."_link_color",
            "std" => "#EE5113",
            "type" => "text"),
			
	array(    "name" => "Navigation Link Color",
            "id" => $shortname."_nav_color",
            "std" => "#8C8C77",
            "type" => "text"),
			
	array(    "name" => "Navigation Hover Border Color",
            "id" => $shortname."_nav_border",
            "std" => "#FF692E",
            "type" => "text"),
			
	array(    "name" => "Font Color",
            "id" => $shortname."_font_color",
            "std" => "#A2A2A2",
            "type" => "text"),
    
    array(    "name" => "Font Type",
            "id" => $shortname."_body_font",
            "type" => "select",
            "std" => "Verdana",
            "options" => array("Verdana", "Arial", "Georgia")),
			
    array(    "name" => "Hide/Display Share Button",
            "id" => $shortname."_share",
            "type" => "select",
            "std" => "visible",
            "options" => array("visible", "hidden")),
			
    array(    "name" => "Hide/Display Close Button",
            "id" => $shortname."_close",
            "type" => "select",
            "std" => "visible",
            "options" => array("visible", "hidden")),
			
	array(    "name" => "About Us Text",
            "id" => $shortname."_about",
            "std" => "Input your about us text here.",
            "type" => "text2"),
			
);

function mytheme_add_admin() {

    global $themename, $shortname, $options;

    if ( $_GET['page'] == basename(__FILE__) ) {
    
        if ( 'save' == $_REQUEST['action'] ) {

                foreach ($options as $value) {
                    update_option( $value['id'], $_REQUEST[ $value['id'] ] ); }

                foreach ($options as $value) {
                    if( isset( $_REQUEST[ $value['id'] ] ) ) { update_option( $value['id'], $_REQUEST[ $value['id'] ]  ); } else { delete_option( $value['id'] ); } }

                header("Location: themes.php?page=functions.php&saved=true");
                die;

        } else if( 'reset' == $_REQUEST['action'] ) {

            foreach ($options as $value) {
                delete_option( $value['id'] ); }

            header("Location: themes.php?page=functions.php&reset=true");
            die;

        }
    }

    add_theme_page($themename." Options", "Current Theme Options", 'edit_themes', basename(__FILE__), 'mytheme_admin');

}

function mytheme_admin() {

    global $themename, $shortname, $options;

    if ( $_REQUEST['saved'] ) echo '<div id="message" class="updated fade"><p><strong>'.$themename.' settings saved.</strong></p></div>';
    if ( $_REQUEST['reset'] ) echo '<div id="message" class="updated fade"><p><strong>'.$themename.' settings reset.</strong></p></div>';
    
?>
<div class="wrap">
<h2><?php echo $themename; ?> settings</h2>

<form method="post">

<table class="optiontable">

<?php foreach ($options as $value) { 
    
if ($value['type'] == "text") { ?>
        
<tr valign="top"> 
    <th scope="row"><?php echo $value['name']; ?>:</th>
    <td>
        <input name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" value="<?php if ( get_settings( $value['id'] ) != "") { echo get_settings( $value['id'] ); } else { echo $value['std']; } ?>" />
    </td>
</tr>
  
<?php } elseif ($value['type'] == "text2") { ?>
        
<tr valign="top"> 
    <th scope="row"><?php echo $value['name']; ?>:</th>
    <td>
        <textarea name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" style="width: 400px; height: 200px;" type="<?php echo $value['type']; ?>"><?php if ( get_settings( $value['id'] ) != "") { echo get_settings( $value['id'] ); } else { echo $value['std']; } ?></textarea>
    </td>
</tr>

<?php } elseif ($value['type'] == "select") { ?>

    <tr valign="top"> 
        <th scope="row"><?php echo $value['name']; ?>:</th>
        <td>
            <select name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>">
                <?php foreach ($value['options'] as $option) { ?>
                <option<?php if ( get_settings( $value['id'] ) == $option) { echo ' selected="selected"'; } elseif ($option == $value['std']) { echo ' selected="selected"'; } ?>><?php echo $option; ?></option>
                <?php } ?>
            </select>
        </td>
    </tr>

<?php 
} 
}
?>

</table>

<p class="submit">
<input name="save" type="submit" value="Save changes" />    
<input type="hidden" name="action" value="save" />
</p>
</form>
<form method="post">
<p class="submit">
<input name="reset" type="submit" value="Reset" />
<input type="hidden" name="action" value="reset" />
</p>
</form>

<?php
}

function mytheme_wp_head() { ?>
<link href="<?php bloginfo('template_directory'); ?>/style.php" rel="stylesheet" type="text/css" />
<?php }

add_action('wp_head', 'mytheme_wp_head');
add_action('admin_menu', 'mytheme_add_admin'); ?>