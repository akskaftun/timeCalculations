<?php 
global $options;
foreach ($options as $value) {
if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); } }
      ?>
	  
<!--Begin About Us Box-->	
<div id="sidebar-wrapper">	
<p class="slide2"><a href="#" class="btn-slide2">about us</a></p>
<div id="panel2">
<p class="panel-inside"><?php echo $artsee_about; ?></p>
</div>
<!--End About Us Box-->	

<!--Begin Random Posts-->	
<p class="slide3"><a href="#" class="btn-slide3">random posts</a></p>
<div id="panel3">
<?php $my_query = new WP_Query('orderby=rand&showposts=3');
while ($my_query->have_posts()) : $my_query->the_post();
?>
<div class="random">
<?php 
$thumb = get_post_meta($post->ID, 'Thumbnail', $single = true);
?>
<?php // if there's a thumbnail
if($thumb !== '') { ?>
<div class="random-image">
<img src="<?php bloginfo('stylesheet_directory'); ?>/timthumb.php?src=<?php echo $thumb; ?>&amp;h=44&amp;w=44&amp;zc=1&amp;q=100" alt="<?php if($thumb_alt !== '') { echo $thumb_alt; } else { echo the_title(); } ?>" />
</div>
<?php } // end if statement
// if there's not a thumbnail
else { echo ''; } ?>

<div class="random-content">
<a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title2('', '...', true, '50') ?></a>
</div>
</div>
<?php endwhile; ?>
<div style="clear: both;"></div>
</div>
<!--End Random Posts-->	

<!--Begin Recent Comments-->	
<p class="slide4"><a href="#" class="btn-slide4">recent comments</a></p>
<div id="panel4">
<div class="recent-comments">
<?php include (TEMPLATEPATH . '/simple_recent_comments.php'); /* recent comments plugin by: www.g-loaded.eu */?>
<?php if (function_exists('src_simple_recent_comments')) { src_simple_recent_comments(6, 60, '', ''); } ?>
</div>
</div>
<!--End Recent Comments-->	

<div id="sidebar">
				
<?php if ( !function_exists('dynamic_sidebar')
        || !dynamic_sidebar() ) : ?>     

<div class="sidebar-box">
<h2>Archives</h2>
<ul>
<?php wp_get_archives('type=monthly'); ?>
</ul>
</div>

<div class="sidebar-box">
<h2>Categories</h2>
<ul>
<?php wp_list_categories('show_count=0&title_li='); ?>
</ul>
</div>

<div class="sidebar-box">           
<h2>Blogroll</h2>
<ul>
<?php get_links(-1, '<li>', '</li>', ''); ?>
</ul> 
</div>

<div class="sidebar-box">
<h2>Search</h2>
<div style="margin-left: 20px;">
<?php include (TEMPLATEPATH . '/searchform.php'); ?>
</div>
</div>

<div class="sidebar-box">   
<h2>Meta</h2>
<ul>
<?php wp_register(); ?>
<li><?php wp_loginout(); ?></li>
<li><a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional">Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a></li>
<li><a href="http://gmpg.org/xfn/"><abbr title="XHTML Friends Network">XFN</abbr></a></li>
<li><a href="http://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress</a></li>
<?php wp_meta(); ?>
</ul>
</div>

<?php endif; ?>
                
</div>     
</div> 
</div>